#pragma once

#include <string>

namespace GameTags
{
	std::string kEmpty = "empty";
	std::string kPlayer = "player";
	std::string kEnemy = "enemy";
}
