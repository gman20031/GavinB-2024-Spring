#pragma once

enum class Direction
{
	kUp = 'w',
	kDown = 's',
	kRight = 'd',
	kLeft = 'a',
	kCount = 4,
};
