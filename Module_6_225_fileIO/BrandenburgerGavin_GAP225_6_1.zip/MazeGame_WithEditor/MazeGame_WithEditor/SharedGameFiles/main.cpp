#include "MazeGameMenuSystem.h"

int main(int argc, char* argv[])
{
	MazeGameStartMenu menu;
	menu.StartMazeGame();
}


// choose play, edit, quit

// EDIT
 // -- Select correct level
 // -- Edit the Level
 // -- save as / save 
