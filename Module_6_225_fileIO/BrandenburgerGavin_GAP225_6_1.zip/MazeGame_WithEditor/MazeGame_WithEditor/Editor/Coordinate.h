struct Coordinates
{
	int x;
	int y;
};


