#include <iostream>

//#include "Inheritance.h"
//#include "StaticComposition.h"
//#include "DynamicComposition.h"
//#include "DynamicCompositionWithPolymorphism.h"
#include "Aggregation.h"

int main()
{
    Example();

    return 0;
}