#pragma once

struct CooridinatePair
{
	int x = 0;
	int y = 0;
};