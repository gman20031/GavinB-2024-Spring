#include "Unit.h"
#include <iostream>

Unit::Unit(const char* pName, int hp, int gatherRate, int range, int attack)
    : m_name{ pName }
    , m_hp{ hp }
    , m_gatherRate{ gatherRate }
    , m_range{ range }
    , m_attack{ attack }
{}

void Unit::ModifyHealth(int amount)
{
    m_hp += amount;
    std::cout << m_name << " has m_hp HP\n";

    if (m_hp <= 0)
    {
        std::cout << m_name << " is dead\n";
    }
}

void Unit::Gather()
{
    std::cout << m_name << " gathers " << m_gatherRate << " resources\n";
}

void Unit::Attack()
{
    std::cout << m_name << " attacks from " << m_range << " resources\n";
}
