#pragma once

#include "Unit.h"

class Peon : public Unit
{
public:
    Peon() : Unit{ "Peon", 5, 5, 1, 1 } {}
};

class Soldier : public Unit
{
public:
    Soldier() : Unit{ "Soldier", 15, 1, 1, 3 } {}
};

class Archer : public Unit
{
public:
    Archer() : Unit{ "Archer", 10, 1, 3, 2 } {}
};