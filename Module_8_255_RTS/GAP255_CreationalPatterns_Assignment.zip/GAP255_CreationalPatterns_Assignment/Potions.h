#pragma once

#include "IUseable.h"

class Unit;

// Potion //

class Potion : public IUseable
{
    Unit* m_pUser;
    int m_heal;

public:
    Potion(Unit* pUser, int amount);
    virtual ~Potion() = default;
    virtual void Use() override;
};

// Buff //

class Buff : public IUseable
{
    Unit* m_pUser;
    int m_attack;

public:
    Buff(Unit* pUser, int amount);
    virtual ~Buff() = default;
    virtual void Use() override;
};