#include "Potions.h"
#include "Unit.h"

// Potion //

Potion::Potion(Unit* pUser, int amount)
    : m_pUser{ pUser }
    , m_heal{ amount }
{
}

void Potion::Use()
{
    m_pUser->ModifyHealth(m_heal);
}

// Buff //

Buff::Buff(Unit* pUser, int amount)
    : m_pUser{ pUser }
    , m_attack{ amount }
{
}

void Buff::Use()
{
    m_pUser->ModifyAttack(m_attack);
}

#pragma endregion // Buff