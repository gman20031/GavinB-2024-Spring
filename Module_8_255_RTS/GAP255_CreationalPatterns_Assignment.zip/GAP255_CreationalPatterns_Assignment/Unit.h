#pragma once

#include <string>

class Unit
{
private:
    std::string m_name;
    int m_hp;
    int m_gatherRate;
    int m_range;
    int m_attack;

public:
    Unit(const char* pName, int hp, int gatherRate, int range, int attack);

    void ModifyHealth(int amount);
    void ModifyAttack(int amount) { m_attack += amount; }

    void Gather();
    void Attack();
};