#include <iostream>
#include "Unit_Implementations.h"

int main()
{
    Peon* pPeon = nullptr;
    Soldier* pSoldier = nullptr;
    Archer* pArcher = nullptr;

    bool doQuit = false;
    while (!doQuit)
    {
        system("cls");

        std::cout << "0: Quit\n"

            << "1: Create Peon\n"
            << "2: Create Soldier\n"
            << "3: Create Archer\n"

            << "4: Gather w/ Peon\n"
            << "5: Gather w/ Soldier\n"
            << "6: Gather w/ Archer\n"

            << "7: Attack w/ Peon\n"
            << "8: Attack w/ Soldier\n"
            << "9: Attack w/ Archer\n";

        char choice = std::getchar();
        std::cin.ignore();

        switch (choice)
        {
        case '0': doQuit = true; break;

            // Creating

        case '1':
            pPeon = new Peon;
            std::cout << "Peon has been created\n";
            break;
        case '2':
            pSoldier = new Soldier;
            std::cout << "Soldier has been created\n"; 
            break;
        case '3':
            pArcher = new Archer;
            std::cout << "Archer has been created\n"; 
            break;

            // Gathering

        case '4':
            if (pPeon == nullptr)
                std::cout << "Peon has not been created\n";
            else
                pPeon->Gather();
            break;
        case '5':
            if (pSoldier == nullptr)
                std::cout << "Soldier has not been created\n";
            else
                pSoldier->Gather();
            break;
        case '6':
            if (pArcher == nullptr)
                std::cout << "Archer has not been created\n";
            else
                pArcher->Gather();
            break;

            // Attacking

        case '7':
            if (pPeon == nullptr)
                std::cout << "Peon has not been created\n";
            else
                pPeon->Attack();
            break;
        case '8':
            if (pSoldier == nullptr)
                std::cout << "Soldier has not been created\n";
            else
                pSoldier->Attack();
            break;
        case '9':
            if (pArcher == nullptr)
                std::cout << "Archer has not been created\n";
            else
                pArcher->Attack();
            break;
        }

        system("pause");
    }

    return 0;
}