#pragma once

#include <conio.h>
#include <iostream>

#include "Map.h"
#include "Player.h"
#include "GameObject.h"

class MazeGame
{
private:

public:
	

	void Run();

};