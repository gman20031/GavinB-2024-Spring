#pragma once

struct Vector2
{
	int x = 0;
	int y = 0;
};