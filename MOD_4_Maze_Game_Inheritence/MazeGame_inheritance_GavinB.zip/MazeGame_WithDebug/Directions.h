#pragma once

enum class Direction
{
	kUp,
	kDown,
	kRight,
	kLeft,
};