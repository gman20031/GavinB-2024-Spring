#include <conio.h>
#include <iostream>

int main()
{
    char map[]{
        '#','#','#','#','#','#','#','#',
        '#','@','.','#','.','.','.','#',
        '#','#','.','.','.','#','.','#',
        '#','#','#','#','.','#','.','#',
        '#','X','.','#','.','#','.','#',
        '#','#','.','#','#','#','.','#',
        '#','#','.','.','.','.','.','#',
        '#','#','#','#','#','#','#','#',
    };

    int playerX = 1;
    int playerY = 1;

    while (true)
    {
        system("cls");
        for (int y = 0; y < 8; ++y)
        {
            for (int x = 0; x < 8; ++x)
            {
                int index = x + y * 8;
                std::cout << map[index] << ' ';
            }
            std::cout << '\n';
        }

        char input = _getch();

        switch (input)
        {
        case 'q':
            return 0;
        case 'w':
        {
            int index = playerX + (playerY - 1) * 8;
            if (map[index] == '.')
            {
                --playerY;
                map[index] = '@';
                map[index + 8] = '.';
            }
            else if (map[index] == 'X')
                return 0;

            break;
        }
        case 's':
        {
            int index = playerX + (playerY + 1) * 8;
            if (map[index] == '.')
            {
                ++playerY;
                map[index] = '@';
                map[index - 8] = '.';
            }
            else if (map[index] == 'X')
                return 0;

            break;
        }
        case 'a':
        {
            int index = (playerX - 1) + playerY * 8;
            if (map[index] == '.')
            {
                --playerX;
                map[index] = '@';
                map[index + 1] = '.';
            }
            else if (map[index] == 'X')
                return 0;

            break;
        }
        case 'd':
        {
            int index = (playerX + 1) + playerY * 8;
            if (map[index] == '.')
            {
                ++playerX;
                map[index] = '@';
                map[index - 1] = '.';
            }
            else if (map[index] == 'X')
                return 0;

            break;
        }
        }
    }


    return 0;
}