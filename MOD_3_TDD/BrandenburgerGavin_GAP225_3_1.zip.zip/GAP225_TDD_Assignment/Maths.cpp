#include "Maths.h"
#include <math.h>
float Maths::Square(float lhs, float rhs)
{
	return lhs * rhs;
}

float Maths::SquareRoot(float squared)
{

}