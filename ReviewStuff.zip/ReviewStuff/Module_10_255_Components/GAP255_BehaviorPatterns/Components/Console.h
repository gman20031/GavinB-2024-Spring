#pragma once

#include <iostream>
#include <Windows.h>

void ConsoleClear();
